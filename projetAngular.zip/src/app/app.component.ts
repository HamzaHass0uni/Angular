import { Component } from '@angular/core';
import 'rxjs/Rx';
import { Observable, Subject, asapScheduler, pipe, of, from, interval, merge, fromEvent } from 'rxjs';





@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {

  secondes : number;
  
 constructor(){

  
 } 
 ngOnInint(){
  const counter = interval(1000);
  counter.subscribe(
    (value:number)=>{
      this.secondes=value;
    },
    (error:any)=> {
      console.log('Une erreur a ete rencontree !');
    },
    ()=>{
      console.log('Observable completee !');
    }
  )
 }

  
}


