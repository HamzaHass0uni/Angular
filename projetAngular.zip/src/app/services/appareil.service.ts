export class AppareilService{

    appareilOne='Machine a laver';
    appareilTwo='Tele';
    appareilThree='Machine a secher';



    appareils = [
        {
          id:1,
          nom: this.appareilOne,
          status: 'eteint'
        },
        {
          id:2,
          nom: this.appareilTwo,
          status: 'allume'
        },
        {
          id:3,
          nom: this.appareilThree,
          status: 'eteint'
        }
      ];

      getAppareilById(id:number){
        const appareil =this.appareils.find(
          (appareilObject)=>{
            return appareilObject.id===id;
          }
        );
        return appareil;
      }
      switchOnAll(){
          for(let appareil of this.appareils)
          {
              appareil.status = 'allume';
          }
      }


      switchOffAll(){
        for(let appareil of this.appareils)
        {

            appareil.status = 'eteint';
        } 
   
    }
    switchOnne(index: number){
      this.appareils[index].status='allume';
    }
    switchOffne(index: number){
      this.appareils[index].status='eteint';
    }




}